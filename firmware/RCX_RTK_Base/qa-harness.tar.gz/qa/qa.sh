#!/usr/bin/env bash
# Full pre-delivery gate. Run this before handing over any file.
#   1. check.sh  — real C++ compiler over the whole project against platform stubs
#   2. lint.py   — the interface seams a compiler cannot see (CSV, DOM, JSON, buffers)
#   3. web.sh    — the dashboards' embedded JavaScript through a real JS parser
# Any non-zero exit means do not ship.
set -u
HERE="$(cd "$(dirname "$0")" && pwd)"
SRC="${1:-/home/claude/base}"
rc=0
"$HERE/check.sh" "$SRC" || rc=1
echo
python3 "$HERE/lint.py" "$SRC" || rc=1
echo
"$HERE/web.sh" "$SRC" || rc=1
echo
if [ $rc -eq 0 ]; then echo "✅ QA GATE PASSED"; else echo "❌ QA GATE FAILED — do not ship"; fi
exit $rc
