# RCX RTK Base — off-target QA gate

Catches on a desk what the project has otherwise been catching on a car roof.
Nothing here ships to the device; it never links, never runs, and touches no firmware file.

## Run it

    ./qa.sh /path/to/RCX_RTK_Base

Non-zero exit means do not flash.

## What each stage does

**`check.sh` — real C++ compiler over the whole project.**
Compiles `RCX_RTK_Base.ino`, `bridge_sd_log.cpp`, `ppp_survey.cpp` and `ppp_web.cpp`
against minimal platform stubs in `stubs/`, with `-fsyntax-only` and warnings turned up.
This is the stage that catches a missing struct member, a `printf` whose arguments do not
match its format, an unhandled type, an always-false comparison.

`genproto.py` reproduces what the Arduino builder does before compiling a sketch: it
generates a forward declaration for every function and splices them in at the first
function definition, so call-before-definition is not reported as an error the real build
would never produce. Prototypes are emitted without default arguments, since a default may
be specified only once.

The host is LP64 and the ESP32 is ILP32, so `uint64_t` is `unsigned long` here and
`unsigned long long` there. A correct `%llu` on a 64-bit value therefore reads as a
mismatch. That one exact pairing is filtered and only that one — a genuine `%llu` on a
32-bit value reports `unsigned int` on the host and still comes through.

**`lint.py` — the seams a compiler cannot see.**
Every check exists because that failure has already happened here:

| check | the failure it catches |
|---|---|
| `csv` | a column added to a header and not to its format string; `snprintf` then misaligns every field after the mismatch |
| `dom` | JavaScript writing to an element id no markup declares, so a row sits at its placeholder forever with no error anywhere |
| `json` | JavaScript reading a key the firmware never emits, which renders as a blank or a zero rather than as a fault |
| `buffers` | a JSON document outgrowing its `snprintf` buffer; the tail is dropped silently and the page fails to parse |
| `sentinel` | a `-1`-means-unknown return clamped to `0` by a caller, publishing the most precise-looking value in the format for the least-known state |

A `sentinel` clamp can be exempted with `// lint: sentinel-ok — <reason>` within a dozen
lines of the call. The marker is deliberately explicit so the exemption is a decision on
the record.

**`web.sh` — the embedded dashboards.**
The pages live inside C++ raw string literals, so a syntax error in them is invisible to
the compiler — the whole page is just a string. This parses each `<script>` with Node and
checks the markup's tag balance.

## Extending the stubs

`stubs/` is a compile-time-only model of the Arduino and ESP-IDF surface this project
uses. When a build fails on a missing platform symbol, add the narrowest declaration that
makes it compile. Do not add behaviour: a stub that appears to work invites trusting it,
and nothing here executes.
