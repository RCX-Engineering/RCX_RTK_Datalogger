#!/usr/bin/env bash
# Off-target syntax and type check for the RCX RTK Base firmware.
#
# Compiles the whole project with a real C++ compiler against minimal platform stubs,
# so type errors, printf format/arity errors and missing struct members are found here
# instead of on the next flash-and-drive cycle. Nothing is executed (-fsyntax-only) and
# nothing about the stubs affects the shipped build — they exist only for this check.
#
# The .ino gets the same treatment the Arduino builder gives it: an Arduino.h prelude
# and auto-generated forward declarations, so call-before-definition is not reported as
# an error the real build would never produce.
set -u
SRC="${1:-/home/claude/base}"
HERE="$(cd "$(dirname "$0")" && pwd)"
STUBS="$HERE/stubs"
WORK="$(mktemp -d)"
cp "$SRC"/*.h "$SRC"/*.cpp "$WORK"/ 2>/dev/null
{
  echo '#include <Arduino.h>'
  echo '#line 1 "RCX_RTK_Base.ino"'
  python3 "$HERE/genproto.py" --splice "$SRC/RCX_RTK_Base.ino"
} > "$WORK/RCX_RTK_Base_ino.cpp"

FLAGS=(-fsyntax-only -std=gnu++17 -x c++
  "-I$STUBS" "-I$WORK"
  -Wall -Wextra -Wformat=2 -Wformat-signedness
  -Wshadow -Wlogical-op -Wduplicated-cond -Wduplicated-branches
  -Wnull-dereference -Wtype-limits -Wsizeof-pointer-memaccess -Wreturn-type
  -Wuninitialized -Wmaybe-uninitialized -Warray-bounds=2 -Wstringop-overflow=4
  -Wno-unused-parameter -Wno-unused-function -Wno-missing-field-initializers
  -Wno-unused-const-variable -Wno-format-nonliteral -Wno-shadow
  -DARDUINO=200 -DESP32 -DARDUINO_ARCH_ESP32 -DARDUINO_USB_CDC_ON_BOOT=1)

rc=0
for f in RCX_RTK_Base_ino.cpp bridge_sd_log.cpp ppp_survey.cpp ppp_web.cpp; do
  [ -f "$WORK/$f" ] || continue
  echo "── $f"
  if ! g++ "${FLAGS[@]}" "$WORK/$f" 2> "$WORK/err.txt"; then rc=1; fi
  # ABI NOTE. The host is LP64, the ESP32 is ILP32. On the host uint64_t is
  # "long unsigned int"; on target it is "long long unsigned int". So a CORRECT %llu on a
  # uint64_t is reported here as a mismatch against "long unsigned int". That one exact
  # pairing is filtered, and only that one: a genuine %llu on a 32-bit value reports
  # "unsigned int" on the host and still comes through. Building 32-bit would remove the
  # need for this, but there is no 32-bit libstdc++ on this machine.
  sed "s#$WORK/##g; s#$STUBS/#stubs/#g" "$WORK/err.txt" \
    | grep -v "^In file included from" \
    | grep -v "expects argument of type 'long long unsigned int', but argument .* has type 'long unsigned int'" \
    | grep -v "expects argument of type 'long long int', but argument .* has type 'long int'" \
    | grep -vE "^ *[0-9]+ \| .*%llu" \
    | head -100
done
rm -rf "$WORK"
[ $rc -eq 0 ] && echo "✅ clean" || echo "❌ errors above"
exit $rc
