#!/usr/bin/env bash
# Parse the JavaScript embedded in each dashboard's raw string literal with a real JS
# engine, and check the markup's tag balance. A syntax error in that literal is invisible
# to the C++ compiler — the whole page is just a string to it — and shows up only as a
# dashboard that renders nothing.
set -u
SRC="${1:-/home/claude/base}"
rc=0
echo "── embedded web assets"
for f in bridge_web_page.h ppp_web.cpp; do
  [ -f "$SRC/$f" ] || continue
  python3 - "$SRC/$f" <<'PY'
import re, sys, subprocess, tempfile, os
path = sys.argv[1]
src = open(path, encoding='utf-8').read()
m = re.search(r'R"([A-Z]*)\(', src)
if not m:
    print(f"  ..  {os.path.basename(path)}: no raw string literal"); sys.exit(0)
delim = m.group(1)
end = src.find(')' + delim + '"')
if end < 0:
    print(f"  ❌  {os.path.basename(path)}: raw string literal is not terminated"); sys.exit(1)
body = src[m.end():end]
rc = 0
for tag in ('div', 'span', 'button', 'a', 'script', 'style', 'table', 'tr', 'td'):
    o = len(re.findall(r'<%s[\s>]' % tag, body)); c = len(re.findall(r'</%s>' % tag, body))
    if o != c:
        print(f"  ❌  {os.path.basename(path)}: <{tag}> opened {o} times, closed {c}"); rc = 1
for i, js in enumerate(re.findall(r'<script[^>]*>(.*?)</script>', body, re.S)):
    with tempfile.NamedTemporaryFile('w', suffix='.js', delete=False) as t:
        t.write(js); tmp = t.name
    r = subprocess.run(['node', '--check', tmp], capture_output=True, text=True)
    os.unlink(tmp)
    if r.returncode:
        print(f"  ❌  {os.path.basename(path)} script {i}: {r.stderr.strip().splitlines()[0]}"); rc = 1
    else:
        print(f"  ok  {os.path.basename(path)} script {i}: parses ({js.count(chr(10))+1} lines)")
sys.exit(rc)
PY
  [ $? -ne 0 ] && rc=1
done
exit $rc
