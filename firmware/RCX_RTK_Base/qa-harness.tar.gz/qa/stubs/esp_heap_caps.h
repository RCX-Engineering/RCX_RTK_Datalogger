#pragma once
#include <cstddef>
#define MALLOC_CAP_8BIT     (1<<2)
#define MALLOC_CAP_INTERNAL (1<<11)
#define MALLOC_CAP_SPIRAM   (1<<10)
#define MALLOC_CAP_DEFAULT  (1<<3)
extern "C" {
size_t heap_caps_get_free_size(uint32_t);
size_t heap_caps_get_largest_free_block(uint32_t);
size_t heap_caps_get_total_size(uint32_t);
size_t heap_caps_get_minimum_free_size(uint32_t);
}
