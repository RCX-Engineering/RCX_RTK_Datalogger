#pragma once
#include "FS.h"
#define SDMMC_FREQ_DEFAULT 20000
#define SDMMC_FREQ_HIGHSPEED 40000
#define SDMMC_FREQ_PROBING 400
#define SDMMC_FREQ_52M 52000
#define SDMMC_FREQ_26M 26000
class SDMMCFS : public fs::FS {
public:
    bool begin(const char* =nullptr,bool=false,bool=false,int=0,uint8_t=5){return false;}
    void end(){}
    bool setPins(int,int,int){return true;}
    bool setPins(int,int,int,int,int,int){return true;}
    uint64_t totalBytes(){return 0;}
    uint64_t usedBytes(){return 0;}
    uint64_t cardSize(){return 0;}
    int cardType(){return 0;}
};
extern SDMMCFS SD_MMC;
