#pragma once
#include <Arduino.h>
#define FILE_READ  "r"
#define FILE_WRITE "w"
#define FILE_APPEND "a"
namespace fs {
class File : public Stream {
public:
    operator bool() const { return false; }
    void close(){}
    size_t size(){return 0;}
    const char* name(){return "";}
    const char* path(){return "";}
    bool isDirectory(){return false;}
    File openNextFile(){return File();}
    size_t write(const uint8_t*,size_t){return 0;}
    size_t write(uint8_t){return 0;}
    size_t print(const char*){return 0;}
    size_t println(const char*){return 0;}
    size_t println(const String&){return 0;}
    int available(){return 0;}
    int read(){return -1;}
    size_t read(uint8_t*,size_t){return 0;}
    size_t readBytes(char*,size_t){return 0;}
    void flush(){}
    bool seek(uint32_t){return false;}
    uint32_t position(){return 0;}
};
class FS {
public:
    File open(const char*,const char* =FILE_READ,bool=false){return File();}
    File open(const String&,const char* =FILE_READ,bool=false){return File();}
    bool exists(const char*){return false;}
    bool remove(const char*){return false;}
    bool rename(const char*,const char*){return false;}
    bool mkdir(const char*){return false;}
};
}
using fs::File;
using fs::FS;
