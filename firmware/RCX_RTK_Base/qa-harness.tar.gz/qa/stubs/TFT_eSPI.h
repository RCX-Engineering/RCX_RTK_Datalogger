#pragma once
#include <Arduino.h>
#define TFT_BLACK 0x0000
#define TFT_WHITE 0xFFFF
#define TFT_RED 0xF800
#define TFT_GREEN 0x07E0
#define TFT_BLUE 0x001F
#define TFT_YELLOW 0xFFE0
#define TFT_ORANGE 0xFD20
#define TFT_CYAN 0x07FF
#define TFT_MAGENTA 0xF81F
#define TFT_DARKGREY 0x7BEF
#define TFT_LIGHTGREY 0xD69A
#define TFT_NAVY 0x000F
#define TFT_MAROON 0x7800
#define TFT_OLIVE 0x7BE0
#define TFT_PURPLE 0x780F
#define TFT_SILVER 0xC618
#define TFT_GOLD 0xFEA0
#define TFT_SKYBLUE 0x867D
#define TFT_PINK 0xFE19
#define TL_DATUM 0
#define TC_DATUM 1
#define TR_DATUM 2
#define MC_DATUM 4
class TFT_eSPI : public Print {
public:
    TFT_eSPI(int=0,int=0){}
    void init(){} void begin(){}
    void setRotation(uint8_t){}
    void fillScreen(uint32_t){}
    void fillRect(int32_t,int32_t,int32_t,int32_t,uint32_t){}
    void drawRect(int32_t,int32_t,int32_t,int32_t,uint32_t){}
    void drawLine(int32_t,int32_t,int32_t,int32_t,uint32_t){}
    void setCursor(int16_t,int16_t){}
    void setCursor(int16_t,int16_t,uint8_t){}
    int16_t getCursorX(){return 0;}
    int16_t getCursorY(){return 0;}
    void setTextColor(uint16_t){}
    void setTextColor(uint16_t,uint16_t,bool=false){}
    void setTextFont(uint8_t){}
    void setTextSize(uint8_t){}
    void setTextDatum(uint8_t){}
    void setTextWrap(bool,bool=false){}
    int16_t drawString(const String&,int32_t,int32_t){return 0;}
    int16_t drawString(const char*,int32_t,int32_t){return 0;}
    int16_t textWidth(const String&){return 0;}
    int16_t fontHeight(){return 8;}
    int32_t width(){return 320;} int32_t height(){return 172;}
};
