#pragma once
#include <Arduino.h>
class Preferences {
public:
    bool begin(const char*,bool=false){return true;}
    void end(){}
    bool clear(){return true;}
    bool remove(const char*){return true;}
    size_t putString(const char*,const String&){return 0;}
    size_t putString(const char*,const char*){return 0;}
    size_t putBool(const char*,bool){return 0;}
    size_t putUInt(const char*,uint32_t){return 0;}
    size_t putInt(const char*,int32_t){return 0;}
    size_t putUShort(const char*,uint16_t){return 0;}
    size_t putFloat(const char*,float){return 0;}
    size_t putDouble(const char*,double){return 0;}
    size_t putBytes(const char*,const void*,size_t){return 0;}
    String getString(const char*,const String& d=String("")){return d;}
    size_t getString(const char*,char*,size_t){return 0;}
    bool   getBool(const char*,bool d=false){return d;}
    uint32_t getUInt(const char*,uint32_t d=0){return d;}
    int32_t  getInt(const char*,int32_t d=0){return d;}
    uint16_t getUShort(const char*,uint16_t d=0){return d;}
    float    getFloat(const char*,float d=0){return d;}
    double   getDouble(const char*,double d=0){return d;}
    size_t   getBytes(const char*,void*,size_t){return 0;}
    bool isKey(const char*){return false;}
};
