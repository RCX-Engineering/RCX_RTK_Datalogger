#pragma once
#include <WiFi.h>
#define HTTP_GET  1
#define HTTP_POST 2
#define HTTP_ANY  255
typedef int HTTPMethod;
class WebServer {
public:
    WebServer(uint16_t=80){}
    void begin(){} void handleClient(){} void close(){} void stop(){}
    void on(const char*,void(*)()){}
    void on(const char*,HTTPMethod,void(*)()){}
    void onNotFound(void(*)()){}
    void send(int,const char*,const String&){}
    void send(int,const char*,const char*){}
    void send_P(int,const char*,const char*){}
    void sendHeader(const String&,const String&,bool=false){}
    void setContentLength(size_t){}
    void sendContent(const String&){}
    void sendContent(const char*,size_t){}
    String arg(const char*){return String("");}
    String arg(int){return String("");}
    String argName(int){return String("");}
    int    args(){return 0;}
    bool   hasArg(const char*){return false;}
    String uri(){return String("");}
    HTTPMethod method(){return HTTP_GET;}
    NetworkClient client(){return NetworkClient();}
};
