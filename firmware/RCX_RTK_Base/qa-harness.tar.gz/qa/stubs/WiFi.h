#pragma once
#include <Arduino.h>
enum wl_status_t { WL_IDLE_STATUS=0, WL_NO_SSID_AVAIL=1, WL_SCAN_COMPLETED=2,
                   WL_CONNECTED=3, WL_CONNECT_FAILED=4, WL_CONNECTION_LOST=5, WL_DISCONNECTED=6 };
#define WIFI_STA 1
#define WIFI_AP  2
#define WIFI_AP_STA 3
class IPAddress {
public:
    IPAddress(){} IPAddress(uint32_t){} IPAddress(uint8_t,uint8_t,uint8_t,uint8_t){}
    String toString() const { return String("0.0.0.0"); }
    operator uint32_t() const { return 0; }
    bool operator==(const IPAddress&) const { return true; }
    bool operator!=(const IPAddress&) const { return false; }
};
class NetworkClient : public Stream {
public:
    int  connect(const char*,uint16_t,int32_t=0){return 0;}
    int  connect(IPAddress,uint16_t,int32_t=0){return 0;}
    uint8_t connected(){return 0;}
    void stop(){}
    void setNoDelay(bool){}
    int  fd(){return -1;}
    size_t write(const uint8_t*,size_t){return 0;}
    size_t write(uint8_t){return 0;}
    IPAddress remoteIP(){return IPAddress();}
    operator bool(){return false;}
};
typedef NetworkClient WiFiClient;
class NetworkServer {
public:
    NetworkServer(uint16_t=0){}
    void begin(){} void end(){} void setNoDelay(bool){}
    NetworkClient accept(){return NetworkClient();}
    NetworkClient available(){return NetworkClient();}
    bool hasClient(){return false;}
};
typedef NetworkServer WiFiServer;
class WiFiClass {
public:
    void mode(int){} 
    void begin(const char*,const char* =nullptr){}
    void disconnect(bool=false,bool=false){}
    wl_status_t status(){return WL_DISCONNECTED;}
    IPAddress localIP(){return IPAddress();}
    IPAddress softAPIP(){return IPAddress();}
    bool softAP(const char*,const char* =nullptr,int=1,int=0,int=4){return true;}
    int  softAPgetStationNum(){return 0;}
    void setAutoReconnect(bool){}
    void persistent(bool){}
    bool hostByName(const char*,IPAddress&){return false;}
    String macAddress(){return String("00:00:00:00:00:00");}
    int scanNetworks(bool=false){return 0;}
    String SSID(int=0){return String("");}
    int32_t RSSI(int=0){return 0;}
    void setSleep(bool){}
    void setTxPower(int){}
};
extern WiFiClass WiFi;
