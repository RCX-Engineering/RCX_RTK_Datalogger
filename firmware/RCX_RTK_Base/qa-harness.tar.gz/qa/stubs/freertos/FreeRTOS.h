#pragma once
#include <cstdint>
#include <cstddef>
typedef uint32_t TickType_t;
typedef int      BaseType_t;
typedef unsigned UBaseType_t;
typedef void*    TaskHandle_t;
typedef void*    QueueHandle_t;
typedef void*    SemaphoreHandle_t;
#define pdTRUE  1
#define pdFALSE 0
#define pdPASS  1
#define portMAX_DELAY 0xFFFFFFFFu
#define configMAX_PRIORITIES 25
#define pdMS_TO_TICKS(ms) ((TickType_t)(ms))
extern "C" {
void vTaskDelay(TickType_t);
TickType_t xTaskGetTickCount();
void vTaskDelete(TaskHandle_t);
BaseType_t xTaskCreate(void(*)(void*),const char*,uint32_t,void*,UBaseType_t,TaskHandle_t*);
BaseType_t xTaskCreatePinnedToCore(void(*)(void*),const char*,uint32_t,void*,UBaseType_t,TaskHandle_t*,BaseType_t);
UBaseType_t uxTaskGetStackHighWaterMark(TaskHandle_t);
}
