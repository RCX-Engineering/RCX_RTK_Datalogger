#pragma once
#include "FreeRTOS.h"
typedef void* StreamBufferHandle_t;
extern "C" {
StreamBufferHandle_t xStreamBufferCreate(size_t,size_t);
size_t xStreamBufferSend(StreamBufferHandle_t,const void*,size_t,TickType_t);
size_t xStreamBufferReceive(StreamBufferHandle_t,void*,size_t,TickType_t);
size_t xStreamBufferBytesAvailable(StreamBufferHandle_t);
size_t xStreamBufferSpacesAvailable(StreamBufferHandle_t);
BaseType_t xStreamBufferReset(StreamBufferHandle_t);
BaseType_t xStreamBufferIsEmpty(StreamBufferHandle_t);
void vStreamBufferDelete(StreamBufferHandle_t);
}
