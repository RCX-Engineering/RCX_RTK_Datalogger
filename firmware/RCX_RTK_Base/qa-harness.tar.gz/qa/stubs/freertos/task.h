#pragma once
#include "FreeRTOS.h"
extern "C" {
BaseType_t xTaskCreate(void(*)(void*),const char*,uint32_t,void*,UBaseType_t,TaskHandle_t*);
BaseType_t xTaskCreatePinnedToCore(void(*)(void*),const char*,uint32_t,void*,UBaseType_t,TaskHandle_t*,BaseType_t);
UBaseType_t uxTaskGetStackHighWaterMark(TaskHandle_t);
}
