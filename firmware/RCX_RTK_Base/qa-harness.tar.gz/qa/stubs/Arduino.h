// Minimal Arduino API surface for OFF-TARGET SYNTAX AND TYPE CHECKING ONLY.
// Not a simulator: nothing here runs. Its whole job is to let a real C++ compiler
// see the project's own code so type errors, arity errors and missing members are
// found on a desk instead of on a car roof.
#pragma once
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <cmath>
#include <string>
#include <vector>
#include "esp_system.h"
using std::isnan; using std::fmax; using std::fmin;
typedef uint8_t byte;
#define PROGMEM
#define F(x) (x)
#define PI 3.14159265358979323846
#define DEG_TO_RAD 0.017453292519943295
#define HIGH 1
#define LOW 0
#define INPUT 0
#define OUTPUT 1
#define INPUT_PULLUP 2
#define SERIAL_8N1 0x800001c
#define DEC 10
#define HEX 16
#define OCT 8
#define BIN 2
unsigned long millis();
unsigned long micros();
void delay(unsigned long);
void delayMicroseconds(unsigned int);
void pinMode(int,int);
void digitalWrite(int,int);
int  digitalRead(int);
long random(long,long);
void yield();
long map(long,long,long,long,long);
template<class T> const T& constrain(const T& v,const T& lo,const T& hi){return v<lo?lo:(v>hi?hi:v);}
// Arduino defines min/max as macros; a lot of sketch code relies on the unqualified name.
template<class A,class B> auto min(A a,B b)->decltype(a<b?a:b){return a<b?a:b;}
template<class A,class B> auto max(A a,B b)->decltype(a>b?a:b){return a>b?a:b;}
float temperatureRead();
// Addressable status LED (esp32-hal-rgb-led.h). Signatures and enum order copied from the
// core header — the ORDER of the enumerators is load-bearing, since the firmware stores one
// of these values in a constant and a reordered enum here would type-check while meaning a
// different colour order than the hardware gets.
typedef enum {
    LED_COLOR_ORDER_RGB,
    LED_COLOR_ORDER_BGR,
    LED_COLOR_ORDER_BRG,
    LED_COLOR_ORDER_RBG,
    LED_COLOR_ORDER_GBR,
    LED_COLOR_ORDER_GRB
} rgb_led_color_order_t;
void rgbLedWrite(uint8_t,uint8_t,uint8_t,uint8_t);
void rgbLedWriteOrdered(uint8_t,rgb_led_color_order_t,uint8_t,uint8_t,uint8_t);

void ledcAttach(uint8_t,uint32_t,uint8_t);
bool ledcAttachPin(uint8_t,uint8_t);
void ledcSetup(uint8_t,uint32_t,uint8_t);
void ledcWrite(uint8_t,uint32_t);
void analogWrite(uint8_t,int);

class String {
public:
    String(){}
    String(const char* s){ if(s) v_=s; }
    String(const std::string& s):v_(s){}
    String(char c){ v_=std::string(1,c); }
    String(int n,int base=10){ char b[32]; snprintf(b,sizeof b,"%d",n); v_=b; (void)base; }
    String(unsigned n,int base=10){ char b[32]; snprintf(b,sizeof b,"%u",n); v_=b; (void)base; }
    String(long n,int base=10){ char b[32]; snprintf(b,sizeof b,"%ld",n); v_=b; (void)base; }
    String(unsigned long n,int base=10){ char b[32]; snprintf(b,sizeof b,"%lu",n); v_=b; (void)base; }
    String(double d,int dec=2){ char b[64]; snprintf(b,sizeof b,"%.*f",dec,d); v_=b; }
    String(float f,int dec=2){ char b[64]; snprintf(b,sizeof b,"%.*f",dec,(double)f); v_=b; }
    const char* c_str() const { return v_.c_str(); }
    unsigned length() const { return (unsigned)v_.size(); }
    char charAt(unsigned i) const { return v_[i]; }
    int indexOf(const String& s) const { auto p=v_.find(s.v_); return p==std::string::npos?-1:(int)p; }
    int indexOf(char c) const { auto p=v_.find(c); return p==std::string::npos?-1:(int)p; }
    int indexOf(char c,unsigned f) const { auto p=v_.find(c,f); return p==std::string::npos?-1:(int)p; }
    int lastIndexOf(char c) const { auto p=v_.rfind(c); return p==std::string::npos?-1:(int)p; }
    String substring(unsigned a) const { return String(v_.substr(a)); }
    String substring(unsigned a,unsigned b) const { return String(v_.substr(a,b-a)); }
    long toInt() const { return atol(v_.c_str()); }
    double toDouble() const { return atof(v_.c_str()); }
    float toFloat() const { return (float)atof(v_.c_str()); }
    void trim(){ while(!v_.empty()&&isspace((unsigned char)v_.front()))v_.erase(v_.begin());
                 while(!v_.empty()&&isspace((unsigned char)v_.back()))v_.pop_back(); }
    void toUpperCase(){ for(auto&c:v_)c=toupper((unsigned char)c); }
    void toLowerCase(){ for(auto&c:v_)c=tolower((unsigned char)c); }
    bool startsWith(const String& s) const { return v_.rfind(s.v_,0)==0; }
    bool endsWith(const String& s) const { return v_.size()>=s.v_.size()&&v_.compare(v_.size()-s.v_.size(),s.v_.size(),s.v_)==0; }
    bool equalsIgnoreCase(const String& s) const { return strcasecmp(v_.c_str(),s.v_.c_str())==0; }
    void replace(const String& a,const String& b){ size_t p=0; while((p=v_.find(a.v_,p))!=std::string::npos){v_.replace(p,a.v_.size(),b.v_); p+=b.v_.size();} }
    void reserve(unsigned){}
    bool isEmpty() const { return v_.empty(); }
    String& operator+=(const String& o){ v_+=o.v_; return *this; }
    String  operator+(const String& o) const { return String(v_+o.v_); }
    bool operator==(const String& o) const { return v_==o.v_; }
    bool operator!=(const String& o) const { return v_!=o.v_; }
    bool operator==(const char* o) const { return o && v_==o; }
    bool operator!=(const char* o) const { return !(*this==o); }
    bool operator<(const String& o) const { return v_<o.v_; }
    bool operator>(const String& o) const { return v_>o.v_; }
    std::string v_;
};
inline String operator+(const char* a,const String& b){ return String(std::string(a)+b.v_); }

class Print {
public:
    virtual ~Print(){}
    size_t print(const char*){return 0;} size_t print(const String&){return 0;}
    size_t print(int){return 0;} size_t print(unsigned){return 0;}
    size_t print(long){return 0;} size_t print(unsigned long){return 0;}
    size_t print(double,int=2){return 0;} size_t print(char){return 0;}
    size_t println(const char*){return 0;} size_t println(const String&){return 0;}
    size_t println(int){return 0;} size_t println(unsigned long){return 0;}
    size_t println(){return 0;} size_t println(double,int=2){return 0;}
    // printf is checked by the compiler — this is the whole point of the harness.
    int printf(const char* f,...) __attribute__((format(printf,2,3)));
    size_t write(uint8_t){return 0;}
    size_t write(const uint8_t*,size_t){return 0;}
};

class Stream : public Print {
public:
    int available(){return 0;}
    int read(){return -1;}
    int peek(){return -1;}
    void flush(){}
    size_t readBytes(char*,size_t){return 0;}
    void setTimeout(unsigned long){}
};

class HardwareSerial : public Stream {
public:
    HardwareSerial(int=0){}
    void begin(unsigned long,uint32_t=SERIAL_8N1,int=-1,int=-1){}
    void end(){}
    void setRxBufferSize(size_t){}
    void setTxBufferSize(size_t){}
    size_t availableForWrite(){return 0;}
    // USB CDC on this board. The real HWCDC blocks up to 100 ms per write with no host
    // draining the endpoint; the firmware sets this to 0 so an unattended console cannot
    // stall the GNSS drain. Modelled so that call is type-checked rather than skipped.
    void setTxTimeoutMs(uint32_t){}
    operator bool() const { return true; }
};
extern HardwareSerial Serial;
extern HardwareSerial Serial0;
extern HardwareSerial Serial1;
extern HardwareSerial Serial2;

class EspClass {
public:
    uint32_t getFreeHeap(){return 0;}
    uint32_t getMinFreeHeap(){return 0;}
    uint32_t getHeapSize(){return 0;}
    uint32_t getMaxAllocHeap(){return 0;}
    uint32_t getPsramSize(){return 0;}
    uint32_t getFreePsram(){return 0;}
    uint32_t getSketchSize(){return 0;}
    uint32_t getFreeSketchSpace(){return 0;}
    uint32_t getFlashChipSize(){return 0;}
    uint8_t  getChipRevision(){return 0;}
    const char* getChipModel(){return "ESP32-S3";}
    uint64_t getEfuseMac(){return 0;}
    uint32_t getCpuFreqMHz(){return 240;}
    void restart(){}
};
extern EspClass ESP;
