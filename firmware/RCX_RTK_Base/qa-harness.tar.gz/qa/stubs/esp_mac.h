#pragma once
#include <cstdint>
typedef enum { ESP_MAC_WIFI_STA=0, ESP_MAC_WIFI_SOFTAP=1, ESP_MAC_BT=2, ESP_MAC_ETH=3 } esp_mac_type_t;
extern "C" int esp_read_mac(uint8_t*, esp_mac_type_t);
