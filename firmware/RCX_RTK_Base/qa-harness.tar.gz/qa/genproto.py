#!/usr/bin/env python3
"""Emit forward declarations for every top-level function definition in a sketch.

Mirrors what the Arduino builder does before handing a .ino to the compiler. Without
this the off-target check reports call-before-definition errors that cannot occur on
target, and those false positives would bury the real findings.
"""
import re, sys

SIG = re.compile(
    r'^(?P<sig>(?:static\s+|inline\s+|volatile\s+)*'
    r'(?:const\s+)?[A-Za-z_][A-Za-z0-9_:<>,\s\*&]*?'
    r'\s+\*?\s*(?P<name>[A-Za-z_][A-Za-z0-9_]*)\s*'
    r'\((?P<args>[^;{)]*)\))\s*\{',
    re.M)

KEYWORDS = {'if','for','while','switch','return','else','do','catch','sizeof'}


def mask(src):
    """Blank out comments and string literals, preserving length and line structure.

    Length preservation is the whole point: every offset computed against the masked
    text is used to splice into the original, so the two must stay index-for-index
    identical. Newlines are kept so reported line numbers still line up."""
    out = list(src)
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == '/' and i + 1 < n and src[i+1] == '/':
            while i < n and src[i] != '\n':
                out[i] = ' '; i += 1
        elif c == '/' and i + 1 < n and src[i+1] == '*':
            out[i] = out[i+1] = ' '; i += 2
            while i < n and not (src[i] == '*' and i + 1 < n and src[i+1] == '/'):
                if src[i] != '\n': out[i] = ' '
                i += 1
            if i < n: out[i] = ' '; out[i+1] = ' '; i += 2
        elif c in '"\'':
            q = c; out[i] = ' '; i += 1
            while i < n and src[i] != q:
                if src[i] == '\\' and i + 1 < n:
                    out[i] = ' '; out[i+1] = ' '; i += 2; continue
                if src[i] != '\n': out[i] = ' '
                i += 1
            if i < n: out[i] = ' '; i += 1
        else:
            i += 1
    return ''.join(out)

def find_defs(src):
    """Return (offset_of_first_definition, [signatures])."""
    stripped = mask(src)
    sigs, first = [], None
    for m in SIG.finditer(stripped):
        if m.group('name') in KEYWORDS:
            continue
        line_start = stripped.rfind('\n', 0, m.start()) + 1
        if m.start() != line_start:
            continue
        sig = strip_defaults(' '.join(m.group('sig').split()))
        if sig.startswith(('class ', 'struct ', 'enum ', 'namespace ')):
            continue
        if first is None:
            first = m.start()
        sigs.append(sig + ';')
    return first, sigs


def strip_defaults(sig):
    """Remove default arguments from a signature.

    A default argument may be specified once only, and the definition is where it
    belongs. Repeating it in a generated prototype is itself an error, which would
    drown the real findings in noise."""
    i = sig.find('(')
    if i < 0:
        return sig
    head, args = sig[:i+1], sig[i+1:sig.rfind(')')]
    out, depth, buf = [], 0, ''
    for c in args:
        if c in '(<[': depth += 1
        elif c in ')>]': depth -= 1
        if c == ',' and depth == 0:
            out.append(buf); buf = ''
        else:
            buf += c
    out.append(buf)
    cleaned = []
    for a in out:
        j, d = -1, 0
        for k, c in enumerate(a):
            if c in '(<[': d += 1
            elif c in ')>]': d -= 1
            elif c == '=' and d == 0 and (k+1 >= len(a) or a[k+1] != '='):
                j = k; break
        cleaned.append((a[:j] if j >= 0 else a).strip())
    return head + ', '.join(x for x in cleaned if x) + ')'


def splice(path):
    """Print the sketch with prototypes spliced in at the first function definition.

    The Arduino builder puts its generated prototypes near the top of the file, which
    works there because a sketch declares its types before its functions. Splicing at
    the first definition instead keeps that property without assuming it: everything
    the prototypes can reference is already in scope at that point.
    """
    src = open(path, encoding='utf-8').read()
    first, sigs = find_defs(src)
    if first is None:
        sys.stdout.write(src)
        return
    line_no = src.count('\n', 0, first) + 1
    sys.stdout.write(src[:first])
    sys.stdout.write('// --- generated forward declarations (mirrors the Arduino builder) ---\n')
    sys.stdout.write('\n'.join(sigs) + '\n')
    sys.stdout.write('// --- end generated ---\n')
    sys.stdout.write('#line %d "RCX_RTK_Base.ino"\n' % line_no)
    sys.stdout.write(src[first:])


def main(path):
    src = open(path, encoding='utf-8').read()
    # Strip comments and string literals so braces inside them cannot fool the scan.
    stripped = mask(src)
    out = []
    for m in SIG.finditer(stripped):
        if m.group('name') in KEYWORDS:
            continue
        # Only top-level definitions: column 0 start.
        line_start = stripped.rfind('\n', 0, m.start()) + 1
        if m.start() != line_start:
            continue
        sig = ' '.join(m.group('sig').split())
        if sig.startswith(('class ', 'struct ', 'enum ', 'namespace ')):
            continue
        out.append(sig + ';')
    for d in out:
        print(d)

if __name__ == '__main__':
    if len(sys.argv) > 2 and sys.argv[1] == '--splice':
        splice(sys.argv[2])
    else:
        main(sys.argv[1])
