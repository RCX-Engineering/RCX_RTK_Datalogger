#!/usr/bin/env python3
"""Static checks for the seams a C++ compiler cannot see.

The firmware talks to three things through interfaces the compiler does not type-check:
the dashboard (a JSON document consumed by JavaScript in a raw string literal), the SD
card (CSV rows whose header and printf format live hundreds of lines apart), and the
snapshot struct that carries state between the sketch and the logger. Every one of those
seams has broken silently in this project at least once, and each break cost a
flash-and-drive cycle to discover.

Each check below exists because that exact failure has happened:

  csv       a column was added to a header and not to its format string, or vice versa;
            snprintf then truncates or misaligns every field after the mismatch.
  dom       a row was added to the dashboard HTML and the JavaScript that fills it was
            written against a different element id, so the row stayed at its placeholder
            forever with no error anywhere.
  json      the JavaScript read a key the firmware never emits, which reads as undefined
            and renders as a blank or a zero rather than as a fault.
  buffers   a JSON document outgrew its snprintf buffer; the tail is dropped silently and
            the dashboard fails to parse a document that looks fine in the source.
  sentinel  a function returning -1 for "unknown" had that value clamped to 0 by a
            caller, publishing the most precise-looking value in the format for the
            least-known state in the system.

Exit code is non-zero if anything is reported.
"""

import os
import re
import sys

FAIL = 0


def report(check, msg):
    global FAIL
    FAIL = 1
    print(f"  [{check}] {msg}")


def mask(src):
    """Blank comments and string literals, preserving length and line structure."""
    out = list(src)
    i, n = 0, len(src)
    while i < n:
        c = src[i]
        if c == '/' and i + 1 < n and src[i + 1] == '/':
            while i < n and src[i] != '\n':
                out[i] = ' '
                i += 1
        elif c == '/' and i + 1 < n and src[i + 1] == '*':
            out[i] = out[i + 1] = ' '
            i += 2
            while i < n and not (src[i] == '*' and i + 1 < n and src[i + 1] == '/'):
                if src[i] != '\n':
                    out[i] = ' '
                i += 1
            if i < n:
                out[i] = out[i + 1] = ' '
                i += 2
        elif c in '"\'':
            q = c
            out[i] = ' '
            i += 1
            while i < n and src[i] != q:
                if src[i] == '\\' and i + 1 < n:
                    out[i] = out[i + 1] = ' '
                    i += 2
                    continue
                if src[i] != '\n':
                    out[i] = ' '
                i += 1
            if i < n:
                out[i] = ' '
                i += 1
        else:
            i += 1
    return ''.join(out)


def joined_literal(text):
    """Concatenate adjacent C string literals into the string the compiler would see."""
    parts = re.findall(r'"((?:[^"\\]|\\.)*)"', text)
    return ''.join(parts)


SPEC = re.compile(r'%[-+ #0]*[0-9*]*\.?[0-9*]*(?:ll|l|hh|h|z|j|t)?[diuoxXfFeEgGaAcspn%]')


def count_specs(fmt):
    return len([s for s in SPEC.findall(fmt) if not s.endswith('%%')])


def split_top_level(text):
    """Split on commas that are not inside brackets, quotes or a ternary."""
    out, buf, depth = [], '', 0
    for c in text:
        if c in '([{<':
            depth += 1
        elif c in ')]}>':
            depth -= 1
        if c == ',' and depth == 0:
            out.append(buf)
            buf = ''
        else:
            buf += c
    if buf.strip():
        out.append(buf)
    return out


# ── csv: header column count vs printf specifier count ──────────────────────
def check_csv(src_dir):
    path = os.path.join(src_dir, 'bridge_sd_log.cpp')
    if not os.path.exists(path):
        return
    src = open(path, encoding='utf-8').read()
    rows = [
        ('STATUS', '"ms,utc_time,uptime_s', 'TAG_STATUS'),
        ('GPS', '"ms,utc_time,fix,fix_name', 'TAG_GPS'),
    ]
    for name, hdr_anchor, tag in rows:
        if hdr_anchor not in src:
            report('csv', f'{name}: header anchor not found — check moved or renamed')
            continue
        i = src.index(hdr_anchor)
        header = joined_literal(src[i:src.index(';', i)])
        cols = header.split(',')
        # Locate this row's own writer by the enqueueText(TAG, line) call that ends it,
        # then walk back to the snprintf that filled the buffer. Unique per row.
        e = src.find(f'enqueueText({tag}, line)')
        if e < 0:
            report('csv', f'{name}: no enqueueText({tag}, line) — check moved or renamed')
            continue
        j = src.rfind('snprintf(line, sizeof(line),', 0, e)
        if j < 0:
            report('csv', f'{name}: no snprintf feeding enqueueText({tag}, line)')
            continue
        k = e
        # The format is the run of ADJACENT literals the compiler concatenates: take
        # literals from the call site until one is followed by something that is not
        # another literal. Stopping at the first literal undercounts a format that was
        # split across lines, which is exactly how both of these rows are written.
        seg = src[j + len('snprintf(line, sizeof(line),'):k]
        lits, pos = [], 0
        while True:
            m2 = re.compile(r'\s*"((?:[^"\\]|\\.)*)"').match(seg, pos)
            if not m2:
                break
            lits.append(m2.group(1))
            pos = m2.end()
        fmt = ''.join(lits)
        n_spec = count_specs(fmt)
        if len(cols) != n_spec:
            report('csv', f'{name} row: {len(cols)} header columns but {n_spec} format '
                          f'specifiers — every field after the mismatch is wrong')
        else:
            print(f'  ok  csv {name}: {len(cols)} columns == {n_spec} specifiers')


# ── json/dom: what the firmware emits vs what the dashboard reads ───────────
ID_IN_HTML = re.compile(r'id="([A-Za-z0-9_]+)"')
ID_IN_JS = re.compile(r"\$\('([A-Za-z0-9_]+)'\)")


def check_dom(src_dir):
    for fname in ('bridge_web_page.h', 'ppp_web.cpp'):
        path = os.path.join(src_dir, fname)
        if not os.path.exists(path):
            continue
        src = open(path, encoding='utf-8').read()
        m = re.search(r'R"([A-Z]*)\(', src)
        if not m:
            continue
        delim = m.group(1)
        body = src[m.end():src.index(f'){delim}"')]
        html_ids = set(ID_IN_HTML.findall(body))
        js_ids = set(ID_IN_JS.findall(body))
        js_ids |= set(re.findall(r"getElementById\('([A-Za-z0-9_]+)'\)", body))
        missing = sorted(js_ids - html_ids)
        for mid in missing:
            report('dom', f'{fname}: JavaScript writes to #{mid}, which no element declares')
        if not missing:
            print(f'  ok  dom {fname}: all {len(js_ids)} scripted ids exist in the markup')


# ── json: keys the firmware emits vs keys the dashboard reads ───────────────
def emitted_keys(src):
    """Keys written by snprintf into a JSON document, e.g. \"acc\":%.3f."""
    return set(re.findall(r'\\"([A-Za-z0-9_]+)\\":', src))


def check_json(src_dir):
    fw = ''
    for f in ('RCX_RTK_Base.ino', 'ppp_survey.cpp'):
        p = os.path.join(src_dir, f)
        if os.path.exists(p):
            fw += open(p, encoding='utf-8').read()
    # ppp_survey builds its JSON with a macro, so pick up the plain form too.
    keys = emitted_keys(fw) | set(re.findall(r'"[,{]?\\?"([A-Za-z0-9_]+)\\?":', fw))
    keys |= set(re.findall(r'PPP_APPEND\(",\\"([A-Za-z0-9_]+)\\":', fw))
    for fname in ('bridge_web_page.h', 'ppp_web.cpp'):
        p = os.path.join(src_dir, fname)
        if not os.path.exists(p):
            continue
        src = open(p, encoding='utf-8').read()
        m = re.search(r'R"([A-Z]*)\(', src)
        if not m:
            continue
        body = src[m.end():src.index(')' + m.group(1) + '"')]
        # Reads of the shape obj.key where obj is a known JSON object binding.
        reads = set()
        for obj in re.findall(r'\b(?:const|let|var)\s+([A-Za-z_][A-Za-z0-9_]*)\s*=\s*d\.[A-Za-z0-9_]+\s*\|\|', body):
            reads |= set(re.findall(r'\b' + obj + r'\.([A-Za-z0-9_]+)\b', body))
        JS_BUILTINS = {'length', 'join', 'map', 'filter', 'some', 'every', 'forEach',
                       'slice', 'push', 'toFixed', 'textContent', 'value', 'style',
                       'indexOf', 'split', 'sort', 'reverse', 'concat', 'includes'}
        # Keys the page ASSIGNS are its own, not the firmware's.
        assigned = set(re.findall(r'\.([A-Za-z0-9_]+)\s*=[^=]', body))
        unknown = sorted(k for k in reads - keys - JS_BUILTINS - assigned)
        for k in unknown:
            report('json', f'{fname}: reads .{k}, which no snprintf in the firmware emits')
        if not unknown:
            print(f'  ok  json {fname}: every key it reads is emitted somewhere')


# ── buffers: JSON documents against the buffer they are built in ────────────
def check_buffers(src_dir):
    p = os.path.join(src_dir, 'RCX_RTK_Base.ino')
    if not os.path.exists(p):
        return
    src = open(p, encoding='utf-8').read()
    for m in re.finditer(r'static char (\w+)\[(\d+)\];', src):
        name, size = m.group(1), int(m.group(2))
        if name != 'buf' or size < 1024:
            continue   # small scratch buffers are not JSON documents
        # Rough lower bound: the literal text of every format string written into it.
        seg = src[m.end():m.end() + 40000]
        lits = re.findall(r'"((?:[^"\\]|\\.)*)"', seg)
        literal_bytes = sum(len(x) for x in lits if '\\"' in x)
        if literal_bytes > size:
            report('buffers', f'{name}[{size}] holds format literals totalling ~{literal_bytes} '
                              f'bytes before any substituted values — snprintf truncates silently')
        else:
            print(f'  ok  buffers {name}[{size}]: ~{literal_bytes} bytes of literal, headroom '
                  f'{size - literal_bytes}')


# ── sentinel: -1 "unknown" returns that a caller clamps to 0 ────────────────
def check_sentinels(src_dir):
    p = os.path.join(src_dir, 'RCX_RTK_Base.ino')
    if not os.path.exists(p):
        return
    src = mask(open(p, encoding='utf-8').read())
    for m in re.finditer(r'f?max\(\s*(\w+)\(\)\s*,\s*0(?:\.0+)?\s*\)', src):
        fn = m.group(1)
        d = re.search(r'\b' + fn + r'\([^)]*\)\s*\{', src)
        if d and 'return -1' in src[d.end():d.end() + 2000]:
            line = src.count('\n', 0, m.start()) + 1
            # A clamp is legitimate when the same document also carries a flag saying
            # whether the value is known. The marker has to be explicit and reasoned so
            # the exemption is a decision on the record, not an accident.
            raw = open(p, encoding='utf-8').read().splitlines()
            near = '\n'.join(raw[max(0, line - 12):line + 2])
            if 'lint: sentinel-ok' in near:
                continue
            report('sentinel', f'line {line}: {fn}() returns -1 for "unknown" and it is '
                               f'clamped to 0 here — unknown becomes a confident zero')
    print('  ok  sentinel: scan complete')


# ── rowfit: the widest CSV row against the queue line that has to carry it ──
def check_rowfit(src_dir):
    """Every CSV row is built in a local buffer, then COPIED into LogLine.text on its way
    to the SD task. If LogLine.text is the smaller of the two, enqueueText() truncates
    with strncpy and the trailing columns vanish from the file with nothing to indicate
    it happened — the header still promises them, so a reader sees short rows and blames
    the parser. This exact failure was live: the status row reached 353 characters
    against a 352-byte line. The csv check cannot catch it, because the header and the
    format string agree perfectly; it is the transport underneath them that is too small.
    """
    cpp = os.path.join(src_dir, 'bridge_sd_log.cpp')
    if not os.path.exists(cpp):
        return
    src = open(cpp, encoding='utf-8').read()
    m = re.search(r'struct LogLine\s*\{.*?char\s+text\[(\d+)\]', src, re.S)
    if not m:
        report('rowfit', 'LogLine.text not found — check moved or renamed')
        return
    line_cap = int(m.group(1))
    worst_name, worst = None, 0
    for bm in re.finditer(r'char line\[(\d+)\];', src):
        size = int(bm.group(1))
        tail = src[bm.end():bm.end() + 6000]
        tm = re.search(r'enqueueText\((TAG_\w+), line\)', tail)
        if not tm:
            continue
        if size > worst:
            worst, worst_name = size, tm.group(1)
        if size > line_cap:
            report('rowfit', f'{tm.group(1)} builds rows in char line[{size}] but '
                             f'LogLine.text is [{line_cap}] — rows longer than '
                             f'{line_cap - 1} chars are silently truncated')
    if worst and worst <= line_cap:
        print(f'  ok  rowfit: widest builder {worst_name} line[{worst}] fits '
              f'LogLine.text[{line_cap}]')


def main():
    src_dir = sys.argv[1] if len(sys.argv) > 1 else '/home/claude/base'
    print('── project lint')
    check_csv(src_dir)
    check_rowfit(src_dir)
    check_dom(src_dir)
    check_json(src_dir)
    check_buffers(src_dir)
    check_sentinels(src_dir)
    print('✅ lint clean' if not FAIL else '❌ lint findings above')
    return FAIL


if __name__ == '__main__':
    sys.exit(main())
